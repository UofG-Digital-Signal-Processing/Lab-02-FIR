file_path = 'ECG_1000Hz.dat'
sample_rate = 1000
freq_resolution = 1
